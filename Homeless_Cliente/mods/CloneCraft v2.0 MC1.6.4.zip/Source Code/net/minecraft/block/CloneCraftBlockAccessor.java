package net.minecraft.block;

public class CloneCraftBlockAccessor {
	
	public static int getSeedItem(BlockCrops block){
		return block.getSeedItem();
	}

}
