package net.minecraft.inventory;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.util.ResourceLocation;

public class CloneCraftInventoryHelper {
	
	public static ResourceLocation getSlotResource(Slot s){
		return s.texture;
	}
	


}
