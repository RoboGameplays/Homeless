package net.minecraft.client.renderer.entity;

import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

public class CloneCraftRenderHook {
	
	public static ResourceLocation getEntityTexture(Render render, Entity entity){
		return render.getEntityTexture(entity);
	}
	
	public static void bindEntityTexture(Render render, Entity entity){
		render.bindEntityTexture(entity);
	}

}
