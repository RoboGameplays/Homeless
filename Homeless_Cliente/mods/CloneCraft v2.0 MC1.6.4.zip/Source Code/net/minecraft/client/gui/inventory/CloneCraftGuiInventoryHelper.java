package net.minecraft.client.gui.inventory;

public class CloneCraftGuiInventoryHelper {

	public static int getGuiLeft(GuiContainer gui){
		return gui.guiLeft;
	}
	
	public static int getGuiTop(GuiContainer gui){
		return gui.guiTop;
	}
	
}
