package net.minecraft.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class CloneCraftItemAccessor {
	
	public static void onFoodEaten(ItemFood food, ItemStack i, World world, EntityPlayer player){
		food.onFoodEaten(i, world, player);
	}

}
