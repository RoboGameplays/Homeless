package net.minecraft.entity;

public class CloneCraftEntityAccessor {

	public static boolean isAIEnabled(EntityLivingBase e){
		return e.isAIEnabled();
	}
	
	public static void setIsImmuneToFire(Entity e, boolean isImmuneToFire){
		e.isImmuneToFire = isImmuneToFire;
		if(e instanceof CCEntityAnything){
			CCEntityAnything e2 = (CCEntityAnything)e;
			if(e2.theEntity != null){
				e2.theEntity.isImmuneToFire = isImmuneToFire;
			}
		}
	}
	
	public static void setSize(EntityLivingBase e, float width, float height){
		e.setSize(width, height);
	}
	
	public static String getLivingSound(EntityLiving e){
		return e.getLivingSound();
	}
	
	public static float getSoundVolume(EntityLiving e){
		return e.getSoundVolume();
	}
	
	public static float getSoundPitch(EntityLiving e){
		return e.getSoundPitch();
	}
	
	public static String getHurtSound(EntityLiving e){
		return e.getHurtSound();
	}
}
