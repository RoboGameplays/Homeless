package net.minecraft.entity;


public class EntityManager {
	
	/*public static void loadAllDetailsIntoEntity(EntityLivingBase from, EntityLivingBase to){
		to.isSwingInProgress = from.isSwingInProgress;
		to.arrowHitTimer = from.arrowHitTimer;
		to.prevHealth = from.prevHealth;
		to.hurtTime = from.hurtTime;
		to.maxHurtTime = from.maxHurtTime;
		to.attackedAtYaw = from.attackedAtYaw;
		to.deathTime = from.deathTime;
		to.attackTime = from.attackTime;
		to.prevSwingProgress = from.prevSwingProgress;
		to.swingProgress = from.swingProgress;
		to.prevLimbYaw = from.prevLimbYaw;
		to.limbYaw = from.limbYaw;
		to.limbSwing = from.limbSwing;
		to.maxHurtResistantTime = from.maxHurtResistantTime;
		to.prevCameraPitch = from.prevCameraPitch;
		to.cameraPitch = from.cameraPitch;
		to.field_70769_ao = from.field_70769_ao;
		to.field_70770_ap = from.field_70770_ap;
		to.renderYawOffset = from.renderYawOffset;
		to.prevRenderYawOffset = from.prevRenderYawOffset;
		to.rotationYawHead = from.rotationYawHead;
		to.prevRotationYawHead = from.prevRotationYawHead;
		to.jumpMovementFactor = from.jumpMovementFactor;
		to.moveStrafing = from.moveStrafing;
		to.moveForward = from.moveForward;
		to.renderDistanceWeight = from.renderDistanceWeight;
		to.preventEntitySpawning = from.preventEntitySpawning;
		to.riddenByEntity = from.riddenByEntity;
		to.ridingEntity = from.ridingEntity;
		to.prevPosX = from.prevPosX;
		to.prevPosY = from.prevPosY;
		to.prevPosZ = from.prevPosZ;
		to.posX = from.posX;
		to.posY = from.posY;
		to.posZ = from.posZ;
		to.motionX = from.motionX;
		to.motionY = from.motionY;
		to.motionZ = from.motionZ;
		to.rotationYaw = from.rotationYaw;
		to.rotationPitch = from.rotationPitch;
		to.prevRotationYaw = from.prevRotationYaw;
		to.prevRotationPitch = from.prevRotationPitch;
		to.boundingBox.setBB(from.boundingBox);
		to.onGround = from.onGround;
		to.isCollidedHorizontally = from.isCollidedHorizontally;
		to.isCollidedVertically = from.isCollidedVertically;
		to.isCollided = from.isCollided;
		to.velocityChanged = from.velocityChanged;
		to.field_70135_K = from.field_70135_K;
		to.isDead = from.isDead;
		to.yOffset = from.yOffset;
		to.width = from.width;
		to.height = from.height;
		to.prevDistanceWalkedModified = from.prevDistanceWalkedModified;
		to.distanceWalkedModified = from.distanceWalkedModified;
		to.distanceWalkedOnStepModified = from.distanceWalkedOnStepModified;
		to.fallDistance = from.fallDistance;
		to.lastTickPosX = from.lastTickPosX;
		to.lastTickPosY = from.lastTickPosY;
		to.lastTickPosZ = from.lastTickPosZ;
		to.stepHeight = from.stepHeight;
		to.noClip = from.noClip;
		to.entityCollisionReduction = from.entityCollisionReduction;
		to.fireResistance = from.fireResistance;
		to.hurtResistantTime = from.hurtResistantTime;
		to.serverPosX = from.serverPosX;
		to.serverPosY = from.serverPosY;
		to.serverPosZ = from.serverPosZ;
		to.ignoreFrustumCheck = from.ignoreFrustumCheck;
		to.isAirBorne = from.isAirBorne;
		to.timeUntilPortal = from.timeUntilPortal;
		to.dimension = from.dimension;
		to.captureDrops = from.captureDrops;
		to.capturedDrops = from.capturedDrops;
		to.inPortal = from.inPortal;
		to.timeInPortal = from.timeInPortal;
		to.teleportDirection = from.teleportDirection;
		to.attackingPlayer = from.attackingPlayer;
		to.recentlyHit = from.recentlyHit;
		to.dead = from.dead;
		to.isJumping = from.isJumping;
		to.randomYawVelocity = from.randomYawVelocity;
		to.newPosRotationIncrements = from.newPosRotationIncrements;
		to.newPosX = from.newPosX;
		to.newPosY = from.newPosY;
		to.newRotationYaw = from.newRotationYaw;
		to.newRotationPitch = from.newRotationPitch;
		to.isInWeb = from.isInWeb;
		to.inWater = from.inWater;
		to.isImmuneToFire = from.isImmuneToFire;*/

/*		to.invulnerable = from.invulnerable;
		to.customEntityData = from.customEntityData;
		to.extendedProperties = from.extendedProperties;
		to.previousEquipment = from.previousEquipment;
		to.potionsNeedUpdate = from.potionsNeedUpdate;
		to.entityLivingToAttack = from.entityLivingToAttack;
		to.revengeTimer = from.revengeTimer;
		to.landMovementFactor = from.landMovementFactor;
		to.jumpTicks = from.jumpTicks;
		to.nextStepDistance = from.nextStepDistance;
		to.fire = from.fire;
		to.firstUpdate = from.firstUpdate;
		to.entityRiderPitchDelta = from.entityRiderPitchDelta;
		to.entityRiderYawDelta = from.entityRiderYawDelta;*/
//	}

}
