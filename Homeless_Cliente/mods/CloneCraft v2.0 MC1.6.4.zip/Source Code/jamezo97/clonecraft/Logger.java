package jamezo97.clonecraft;

public class Logger {
	/**
	 * Prints to the console the string 's' with prefix [Info] [CloneCraft]
	 * @param s
	 */
	public static void log(String s){
		System.out.println("[Info] [CloneCraft] " + s);
	}
	/**
	 * Prints to the console the string 's' with prefix [ERROR] [CloneCraft]
	 * @param s
	 */
	public static void error(String s){
		System.out.println("[ERROR] [CloneCraft] " + s);
	}
	/**
	 * Prints to the console the string 's' with prefix [CC]
	 * @param s
	 */
	public static void out(String s){
		System.out.println("[CC] " + s);
	}
	
	public static void getAttention(){
		System.out.println("OMGOMGOMGOMG LOOK AT ME I AM GETTING YOUR ATTENTION <3");
	}
/*	
	public static Logger instance;
	
	static{
		instance = new Logger();
	}
*/
	public static void showLineOccured() {
		StackTraceElement[] stacks = Thread.currentThread().getStackTrace();
		if(stacks.length > 1){
			StackTraceElement secondLast = stacks[stacks.length-2];
			System.out.println("[ERROR] [CloneCraft] Error occured near line " + secondLast.getLineNumber() + " in method " + secondLast.getMethodName() + " in class " + secondLast.getClassName());
		}
	}

}
