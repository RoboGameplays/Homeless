package jamezo97.clonecraft;

import java.util.Random;

import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.ForgeSubscribe;

import org.lwjgl.opengl.GL11;

public class EventSubscribed {
	
/*	Random r = new Random();
	
	@ForgeSubscribe()
	public void renderLast(RenderWorldLastEvent event){
//		System.out.println("Render last");
		GL11.glTranslated(r.nextFloat(), r.nextFloat(), r.nextFloat());
	}
	
	@ForgeSubscribe()
	public void drawBox(DrawBlockHighlightEvent event){
		System.out.println("Render lastsss");
		GL11.glTranslated(r.nextFloat(), r.nextFloat(), r.nextFloat());
	}*/

}
