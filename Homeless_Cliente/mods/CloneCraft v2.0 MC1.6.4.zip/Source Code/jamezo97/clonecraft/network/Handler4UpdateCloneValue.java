package jamezo97.clonecraft.network;

import jamezo97.clonecraft.Logger;
import jamezo97.clonecraft.entity.clone.EntityClone;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.INetworkManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class Handler4UpdateCloneValue /*extends Handler*/{
	
/*	@Value(id = 0)
	int entityID;
	@Value(id = 1)
	int dimensionID;
	@Value(id = 2)
	int valueID;
	@Value(id = 3)
	Object[] value = null;
	
	public Handler4UpdateCloneValue(){
		
	}
	
	public Handler4UpdateCloneValue(EntityClone clone, int valueID, Object... value){
		this.entityID = clone.entityId;
		this.dimensionID = clone.worldObj.provider.dimensionId;
		this.valueID = valueID;
		this.value = value;
	}

	@Override
	public void handle(Side side, INetworkManager manager, EntityPlayer player) {
		if(side == Side.CLIENT){
			HandleClient(player);
		}else if(side == Side.SERVER){
			HandleServer(player);
		}
	}
	
	@SideOnly(value = Side.CLIENT)
	public void HandleClient(EntityPlayer sender){
		Minecraft mc = Minecraft.getMinecraft();
		World world = mc.theWorld;
		Entity e = world.getEntityByID(entityID);
		if(e != null && e instanceof EntityClone){
			set((EntityClone)e, sender);
		}
	}

	public void HandleServer(EntityPlayer sender){
		MinecraftServer server = MinecraftServer.getServer();
		World world = server.worldServerForDimension(dimensionID);
		Entity e = world.getEntityByID(entityID);
		if(e != null && e instanceof EntityClone){
			if(((EntityClone)e).canClientSetValue(valueID, value, sender)){
				set((EntityClone)e, sender);
			}else{
				((EntityClone)e).sendValueToClient(valueID, sender);
			}
		}
	}
	
	public void set(EntityClone clone, EntityPlayer sender){
		clone.preValueSet(Side.CLIENT, valueID, value, sender);
		clone.setValueEnd(valueID, value);
		clone.postValueSet(Side.CLIENT, valueID, value, sender);
	}*/

}
