package jamezo97.clonecraft.entity.clone;
	
public enum PlayerTeam{
		Red(0, 0xff0000), Orange(1, 0xff8000), Yellow(2, 0xffff00), Green(3, 0x00ff00), Blue(4, 0x0000ff), LightBlue(5, 0x0080ff),
		Purple(6, 0xc800ff), Pink(7, 0xffaaff), Good(8, 0xffffff), Evil(9, 0x555555), Traitor(10, 0x222222);
		
		public static PlayerTeam getByName(String s){
			PlayerTeam[] allTeam = values();
			for(int a = 0; a < allTeam.length; a++){
				if(allTeam[a].name().equals(s)){
					return allTeam[a];
				}
			}
			for(int a = 0; a < allTeam.length; a++){
				if(allTeam[a].teamID == 3){
					return allTeam[a];
				}
			}
			return allTeam[0];
		}
		
		public static PlayerTeam getByID(int teamID2) {
			PlayerTeam[] allTeam = values();
			for(int a = 0; a < allTeam.length; a++){
				if(allTeam[a].teamID == teamID2){
					return allTeam[a];
				}
			}
			for(int a = 0; a < allTeam.length; a++){
				if(allTeam[a].teamID == 3){
					return allTeam[a];
				}
			}
			return allTeam[0];
		}
		
		public int teamID;
		public int teamColour;
		
		PlayerTeam(int id, int colour){
			teamID = id;
			teamColour = colour;
		}
	}