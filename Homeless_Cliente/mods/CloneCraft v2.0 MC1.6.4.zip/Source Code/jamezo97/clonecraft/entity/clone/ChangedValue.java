package jamezo97.clonecraft.entity.clone;

public class ChangedValue {
	
	public int valueId;
	
	//True = Send to high priority watchers, ie, owners, otherwise: all watchers.
	public boolean priority;
	
	public ChangedValue(int valueId, boolean priority){
		this.valueId = valueId;
		this.priority = priority;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ChangedValue){
			return ((ChangedValue)obj).valueId == valueId && ((ChangedValue)obj).priority == priority;
		}
		return this == obj;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return new ChangedValue(valueId, priority);
	}
	
	

}
