package jamezo97.clonecraft.entity.clone;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.world.World;

public class EntityAttackEntry {

	public String name;
	
	public Class theClass;
	
	public int entityId;
	
	public EntityAttackEntry(String name, Class theClass, int entityId){
		this.name = name;
		this.theClass = theClass;
		this.entityId = entityId;
	}
	
	public EntityLiving instantiate(World world){
		if(isCreated){
			return created;
		}
		Entity e = EntityList.createEntityByName(name, world);
		isCreated = true;

		if(e instanceof EntityLiving){
			created = (EntityLiving)e;
		}
		return created;
	}
	boolean isCreated = false;
	EntityLiving created = null;
	
}
