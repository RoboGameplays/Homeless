package jamezo97.clonecraft.dna;

import java.util.ArrayList;
import java.util.List;

import jamezo97.clonecraft.entity.EntityModifiable;
import net.minecraft.entity.CCEntityAnything;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIArrowAttack;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIBreakDoor;
import net.minecraft.entity.ai.EntityAICreeperSwell;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAITaskEntry;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGiantZombie;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityWitch;
import net.minecraft.entity.monster.EntityZombie;

public class GeneEvil extends Gene{

	public GeneEvil(int id) {
		super(id);
	}

	@Override
	public String getName() {
		return "Aggresive";
	}

	@Override
	public int getMaxAmount() {
		return 1;
	}



	@Override
	public String getStringValue(int amount) {
		return amount*100 + "% Aggressive";
	}

	@Override
	public int getColour() {
		return 0xffaa4233;
	}

	@Override
	public void addGeneEffect(EntityLivingBase entity, int level) {
	}

	@Override
	public Class[] getEntityClassesWithGene() {
		return new Class[]{EntityCreeper.class, EntitySkeleton.class, EntitySpider.class, EntityGiantZombie.class, EntityZombie.class, EntitySlime.class, EntityGhast.class, EntityPigZombie.class, EntityEnderman.class, EntityCaveSpider.class, EntitySilverfish.class, EntityBlaze.class, EntityMagmaCube.class, EntityDragon.class, EntityWither.class, EntityWitch.class};
	}
	//EntityCreeper.class, EntitySkeleton.class, EntitySpider.class, EntityGiantZombie.class, EntityZombie.class, EntitySlime.class, EntityGhast.class, EntityPigZombie.class, EntityEnderman.class, EntityCaveSpider.class, EntitySilverfish.class, EntityBlaze.class, EntityMagmaCube.class, EntityDragon.class, EntityWither.class, EntityWitch.class

	Class[] aiTaskRemove = new Class[]{EntityAIBreakDoor.class, EntityAIAttackOnCollide.class, EntityAIArrowAttack.class,
			EntityAICreeperSwell.class, EntityAIHurtByTarget.class, EntityAILeapAtTarget.class};

	@Override
	public void onUpdate(EntityLivingBase entity, IModifiable mod, int level) {
		if(entity instanceof EntityLiving){
			EntityLiving affect = (EntityLiving)entity;
			if(entity instanceof CCEntityAnything){
				affect = ((CCEntityAnything)entity).theEntity;
			}
			if(affect != null){
				List<EntityAITaskEntry> tasks = (List<EntityAITaskEntry>)affect.tasks.taskEntries;
				if(tasks.size() > 0){
					boolean EntityAIBreakDoor = false;
					boolean EntityAIAttackOnCollide = false;
					boolean EntityAIArrowAttack = false;
					boolean EntityAIHurtByTarget = false;
					boolean EntityAILeapAtTarget = false;
					for(int a = 0; a < tasks.size(); a++){

					}
				}
			}

		}
	}
	
	
}
