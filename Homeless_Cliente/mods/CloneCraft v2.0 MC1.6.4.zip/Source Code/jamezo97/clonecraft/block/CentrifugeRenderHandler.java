package jamezo97.clonecraft.block;

import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.world.IBlockAccess;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;

public class CentrifugeRenderHandler implements ISimpleBlockRenderingHandler{

	int id;
	
	public CentrifugeRenderHandler(int id){
		this.id = id;
	}
	
	@Override
	public void renderInventoryBlock(Block par1Block, int par2, int modelID, RenderBlocks rb) {
		GL11.glPushMatrix();
		GL11.glDisable(GL11.GL_LIGHTING);
		TileEntityCentrifugeRenderer.renderCentrifuge(null, 0, 0, 0, 0);
		GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glPopMatrix();
	}

	@Override
	public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
		return true;
	}

	@Override
	public boolean shouldRender3DInInventory() {
		return true;
	}

	@Override
	public int getRenderId() {
		return id;
	}
}
