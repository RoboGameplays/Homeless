package jamezo97.clonecraft.recipe;

import jamezo97.clonecraft.CloneCraft;
import jamezo97.clonecraft.dna.DNA;

import java.util.ArrayList;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import cpw.mods.fml.common.ICraftingHandler;

public class CloneCraftCraftingHandler implements ICraftingHandler {
	
	public static void add(IOnCrafted i){
		crafters.add(i);
	}
	
	private static ArrayList<IOnCrafted> crafters = new ArrayList<IOnCrafted>();
	

	@Override
	public void onCrafting(EntityPlayer player, ItemStack item, IInventory craftMatrix) {
		for(int a = 0; a < crafters.size(); a++){
			if(crafters.get(a).isValidItem(item, craftMatrix)){
				crafters.get(a).onCrafted(player, item, craftMatrix);
			}
		}
	}


	@Override
	public void onSmelting(EntityPlayer player, ItemStack item) {
		
	}

}
