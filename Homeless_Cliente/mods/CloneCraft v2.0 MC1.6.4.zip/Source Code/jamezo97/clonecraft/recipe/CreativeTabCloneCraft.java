package jamezo97.clonecraft.recipe;

import jamezo97.clonecraft.CloneCraft;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class CreativeTabCloneCraft extends CreativeTabs{

    public int getTabIconItemIndex()
    {
        return CloneCraft.instance.needle.itemID;
    }

    public CreativeTabCloneCraft(String label) {
		super(label);
	}

}
