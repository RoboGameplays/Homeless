package jamezo97.clonecraft.item;

import jamezo97.clonecraft.CloneCraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.item.ItemSimpleFoiled;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemSoul extends ItemSimpleFoiled{

	long lastTickRun = 0;
	
	public ItemSoul(int par1) {
		super(par1);
	}

	@Override
	public void onUpdate(ItemStack par1ItemStack, World par2World, Entity par3Entity, int par4, boolean par5) {
		if(par3Entity != null && CloneCraft.instance.ticks != lastTickRun){
			lastTickRun = CloneCraft.instance.ticks;
			if(par3Entity.isCollidedVertically){
				par3Entity.motionX *= 0.4D;
				par3Entity.motionZ *= 0.4D;
			}
			if(par2World.isRemote){
				if(par2World.rand.nextInt(150) == 0){
					par2World.playSound(par3Entity.posX + (par2World.rand.nextFloat()*6-3f), par3Entity.posY, par3Entity.posZ + (par2World.rand.nextFloat()*6-3f), "clonecraft.soul", 0.3F, par2World.rand.nextFloat() * 0.4F + 0.8F, false);
				}
			}
		}
	}
	
	

}
