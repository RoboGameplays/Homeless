package jamezo97.clonecraft.gui;

import jamezo97.clonecraft.CloneCraft;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class SlotCentrifuge extends Slot{

	public SlotCentrifuge(IInventory iinventory, int i, int j, int k) {
		super(iinventory, i, j, k);
	}
	
	public boolean isItemValid(ItemStack itemstack) {
		if(itemstack.itemID == CloneCraft.testTube.itemID && itemstack.getItemDamage() == 1){
			return true;
		}
		return false;
	}

	@Override
	public int getSlotStackLimit() {
		return 1;
	}
	
	
	
	

}
