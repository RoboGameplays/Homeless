package jamezo97.clonecraft.gui;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiTextField;

public class GuiOnlyTextField extends GuiTextField{

	String allowedChars;
	
	public GuiOnlyTextField(FontRenderer par1FontRenderer, int par2, int par3, int par4, int par5, String allowedChars) {
		super(par1FontRenderer, par2, par3, par4, par5);
		this.allowedChars = allowedChars;
	}
	
	private boolean isAllowedCharacter(char par1) {
		if(allowedChars.indexOf(par1) > -1){
			return true;
		}
		return false;
	}
	
	

}
