package jamezo97.clonecraft.gui;

import jamezo97.clonecraft.CloneCraft;
import jamezo97.clonecraft.dna.ItemData;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class SlotContaminatedItem extends Slot {

	public SlotContaminatedItem(IInventory par1iInventory, int par2, int par3, int par4) {
		super(par1iInventory, par2, par3, par4);
	}

	@Override
	public boolean isItemValid(ItemStack par1ItemStack) {
		if((par1ItemStack.itemID == CloneCraft.needle.itemID || par1ItemStack.itemID == CloneCraft.testTube.itemID) && par1ItemStack.getItemDamage() == 0 && 
				new ItemData(par1ItemStack).isContaminated()){
			return true;
		}
		return false;
	}

}
