package jamezo97.clonecraft.gui;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiTextField;

public class GuiTextFieldClearable extends GuiTextField{
	
	int xPos, yPos, width, height;
	
	public GuiTextFieldClearable(FontRenderer par1FontRenderer, int par2, int par3, int par4, int par5) {
		super(par1FontRenderer, par2, par3, par4, par5);
		this.xPos = par2;
		this.yPos = par3;
		this.width = par4;
		this.height = par5;
	}

	public boolean isInRange(int x, int y){
        boolean var4 = x >= this.xPos && x < this.xPos + this.width && y >= this.yPos && y < this.yPos + this.height;
        return var4;
	}

}
