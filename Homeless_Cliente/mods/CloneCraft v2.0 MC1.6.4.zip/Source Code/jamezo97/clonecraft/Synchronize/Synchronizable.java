package jamezo97.clonecraft.Synchronize;

public interface Synchronizable {
	
	public void sendData(SyncData[] data);
	
	public boolean canSet(int id, Object value, Object setter);
	
	public void anteSet(int id, Object value);
	
	public void postSet(int id, Object value);
	
	public DataSynchronizer getSyncer();

}
