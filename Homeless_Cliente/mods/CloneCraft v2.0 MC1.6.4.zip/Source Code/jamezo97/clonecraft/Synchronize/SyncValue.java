package jamezo97.clonecraft.Synchronize;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(value = RetentionPolicy.RUNTIME)
public @interface SyncValue {
	
	public int uniqueId();
	
	public int callId();
	
	public int subId() default 0;
	
	public int channel() default 0;

}
