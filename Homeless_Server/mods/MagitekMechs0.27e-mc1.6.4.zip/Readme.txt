MTMechs Version 0.27 for Minecraft 1.6.4

-Installation-

Install the latest 1.6.4 forge for your instance.
Place this zip unextracted in the /mods/ folder of your minecraft instance. (i.e. C:/Users/Name/AppData/Roaming/.minecraft/mods/)

-Use notes-

Mechs need fuel: Shift right-click a placed mech to open the gui.
Right-click to mount/ride.
Press 'C' while mounted to fire a beam. You can change the key in the menu options.
Press 'B' while mounted to park/unpark.